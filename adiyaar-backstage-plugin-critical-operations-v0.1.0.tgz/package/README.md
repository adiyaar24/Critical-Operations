# Day 2 Operations Plugin

A Backstage plugin that provides Day 2 operations buttons for entities, enabling seamless integration with Harness workflows with pre-filled form data from entity metadata.

## Features

- **Dynamic Metadata Resolution**: Automatically resolves entity metadata at runtime
- **Pre-filled Workflow Forms**: Generates properly encoded URLs that pre-populate Harness workflow forms
- **Multiple Action Buttons**: Support for multiple workflow actions with different styles
- **Per-Action Hidden Data**: Each action can have its own hidden form data
- **Confirmation Dialogs**: Optional confirmation before executing operations
- **Preview Mode**: Optional preview of form data that will be sent

## Usage

```typescript
import { Day2OperationsCard } from '@adiyaar/backstage-plugin-critical-operations';

<Day2OperationsCard
  title="Day 2 Operations"
  actions={[
    {
      name: 'Update Service',
      url: 'https://app.harness.io/ng/account/YOUR_ACCOUNT/module/idp/create/templates/default/Update_Template',
      color: 'primary',
      variant: 'contained',
      hiddenData: {
        operation_type: 'update',
        priority: 'high'
      }
    },
    {
      name: 'Delete Service',
      url: 'https://app.harness.io/ng/account/YOUR_ACCOUNT/module/idp/create/templates/default/Delete_Template',
      color: 'error',
      variant: 'outlined',
      hiddenData: {
        operation_type: 'delete',
        confirmation_required: true
      }
    }
  ]}
  metadataPath="metadata.additionalInfo.deployment"
  showPreview={true}
  confirmationRequired={true}
/>
```

## Props

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `title` | string | "Day 2 Operations" | Card title |
| `actions` | WorkflowAction[] | - | Array of workflow actions |
| `metadataPath` | string | - | Path to metadata for form data |
| `showPreview` | boolean | true | Show form data preview |
| `confirmationRequired` | boolean | true | Show confirmation dialog |

## WorkflowAction Interface

```typescript
interface WorkflowAction {
  name: string;
  url: string;
  color?: 'primary' | 'secondary' | 'success' | 'error' | 'info' | 'warning';
  variant?: 'contained' | 'outlined' | 'text';
  hiddenData?: Record<string, any>;
}
```

## How It Works

1. **Extracts metadata** from the specified `metadataPath`
2. **Combines with hidden data** specific to each action
3. **Encodes as URL parameter** in `formData` query parameter
4. **Opens Harness workflow** with pre-filled form

## Generated URLs

The plugin generates URLs like:
```
https://app.harness.io/.../templates/default/My_Template?formData=%7B%22key%22%3A%22value%22%7D
```

Where `formData` contains URL-encoded JSON with the resolved metadata and hidden data.